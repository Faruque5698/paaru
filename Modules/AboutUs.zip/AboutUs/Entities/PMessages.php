<?php

namespace Modules\AboutUs\Entities;

use Illuminate\Database\Eloquent\Model;

class PMessages extends Model
{
    protected $fillable = [
      'message',
    ];
}
